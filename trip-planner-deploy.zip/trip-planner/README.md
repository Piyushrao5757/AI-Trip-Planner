# Wandr ✦ AI Trip Planner

A full AI-powered travel planning web app built with vanilla HTML/CSS/JS and Claude AI.

## Features
- 3-step guided trip builder (destination, dates/budget, preferences)
- AI-generated personalised day-by-day itineraries
- Budget breakdown across flights, hotels & activities
- Responsive, mobile-friendly design
- Deployable on Netlify in minutes

## Project Structure
```
trip-planner/
├── index.html          # Main app page
├── css/
│   └── style.css       # Full stylesheet
├── js/
│   └── app.js          # App logic + Claude API integration
├── netlify.toml        # Netlify deploy config
└── README.md
```

## Deploy to Netlify

### Option 1: Drag & Drop (Fastest)
1. Zip the entire `trip-planner` folder
2. Go to [netlify.com](https://netlify.com) → **Add new site → Deploy manually**
3. Drag the zip onto the deploy area
4. Done! Your site is live.

### Option 2: GitHub + Netlify CI/CD
1. Push this folder to a GitHub repo
2. Connect the repo in Netlify dashboard
3. Set build settings: publish directory = `.` (root), no build command
4. Deploy!

## API Key Setup (Required)

The app calls the Anthropic Claude API directly from the browser. You need to set up an API key.

### Steps:
1. Get your API key from [console.anthropic.com](https://console.anthropic.com)
2. In `js/app.js`, the fetch call uses the key — for production, add it as a Netlify environment variable and use a serverless function (see below)

### For Production (Secure):
Create `netlify/functions/generate.js`:
```js
exports.handler = async (event) => {
  const body = JSON.parse(event.body);
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true'
    },
    body: JSON.stringify(body)
  });
  const data = await response.json();
  return { statusCode: 200, body: JSON.stringify(data) };
};
```
Then update `app.js` to call `/.netlify/functions/generate` instead.

Set `ANTHROPIC_API_KEY` in Netlify → Site Settings → Environment Variables.

## Tech Stack
- HTML5, CSS3, Vanilla JS
- Claude Sonnet (claude-sonnet-4-20250514) via Anthropic API
- Google Fonts (Cormorant Garamond + DM Sans)
- Netlify hosting

## License
MIT
