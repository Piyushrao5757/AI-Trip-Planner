/* ===== WANDR — AI TRIP PLANNER JS ===== */

// ---- State ----
let travellerCount = 2;
let currentStep = 1;

// ---- Multi-select chip groups ----
document.querySelectorAll('.chip-group').forEach(group => {
  const isMulti = group.classList.contains('multi');
  group.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      if (isMulti) {
        chip.classList.toggle('active');
      } else {
        group.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
        chip.classList.add('active');
      }
    });
  });
});

// ---- Step navigation ----
function goStep(n) {
  if (n === 2) {
    const origin = document.getElementById('origin').value.trim();
    const dest = document.getElementById('destination').value.trim();
    if (!origin || !dest) {
      shakeField(!origin ? 'origin' : 'destination');
      return;
    }
  }
  if (n === 3) {
    const dep = document.getElementById('depDate').value;
    const ret = document.getElementById('retDate').value;
    if (!dep || !ret) {
      shakeField(!dep ? 'depDate' : 'retDate');
      return;
    }
    if (new Date(ret) <= new Date(dep)) {
      shakeField('retDate');
      showToast('Return date must be after departure.');
      return;
    }
  }

  document.querySelectorAll('.form-step').forEach(s => s.classList.remove('active'));
  document.getElementById('step' + n).classList.add('active');
  document.querySelectorAll('.fstep').forEach(s => {
    s.classList.remove('active');
    if (parseInt(s.dataset.step) <= n) s.classList.add('active');
  });
  currentStep = n;
}

function shakeField(id) {
  const el = document.getElementById(id);
  el.style.borderColor = 'rgba(232,121,138,0.7)';
  el.style.animation = 'shake 0.4s ease';
  setTimeout(() => {
    el.style.borderColor = '';
    el.style.animation = '';
  }, 600);
}

function showToast(msg) {
  const t = document.createElement('div');
  t.style.cssText = `position:fixed;bottom:32px;left:50%;transform:translateX(-50%);background:#1e1e2a;border:1px solid rgba(232,121,138,0.4);color:#e8798a;padding:12px 24px;border-radius:99px;font-size:0.85rem;z-index:9999;animation:fadeIn 0.3s ease`;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

// Inject shake keyframes
const shakeStyle = document.createElement('style');
shakeStyle.textContent = `@keyframes shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}`;
document.head.appendChild(shakeStyle);

// ---- Counter ----
function changeCount(delta) {
  travellerCount = Math.max(1, Math.min(12, travellerCount + delta));
  document.getElementById('travellerCount').textContent = travellerCount;
}

// ---- Budget Slider ----
function updateBudget(val) {
  document.getElementById('budgetVal').textContent = parseInt(val).toLocaleString();
}
// Set min date to today
window.addEventListener('DOMContentLoaded', () => {
  const today = new Date().toISOString().split('T')[0];
  document.getElementById('depDate').min = today;
  document.getElementById('retDate').min = today;
});

// ---- Generate Itinerary ----
async function generateItinerary() {
  const origin = document.getElementById('origin').value.trim();
  const destination = document.getElementById('destination').value.trim();
  const depDate = document.getElementById('depDate').value;
  const retDate = document.getElementById('retDate').value;
  const budget = document.getElementById('budgetSlider').value;

  const tripType = getSelectedChip('tripType');
  const accom = getSelectedChip('accomPref');
  const pace = getSelectedChip('pace');
  const interests = getSelectedChips('interests');

  // Show loading
  showPanel('loading');
  const loadingMsgs = [
    'Analysing your travel preferences…',
    'Searching live flight data…',
    'Scanning hotel availability…',
    'Optimising your budget allocation…',
    'Curating personalised activities…',
    'Building your day-by-day plan…',
  ];
  let msgIdx = 0;
  const msgEl = document.getElementById('loadingMsg');
  msgEl.textContent = loadingMsgs[0];
  const msgInterval = setInterval(() => {
    msgIdx = (msgIdx + 1) % loadingMsgs.length;
    msgEl.textContent = loadingMsgs[msgIdx];
  }, 2200);

  const numDays = Math.round((new Date(retDate) - new Date(depDate)) / 86400000);
  const formattedDep = formatDate(depDate);
  const formattedRet = formatDate(retDate);

  const prompt = `You are an expert AI travel planner. Create a highly personalised, detailed trip itinerary.

Trip details:
- Origin: ${origin}
- Destination: ${destination}
- Dates: ${formattedDep} to ${formattedRet} (${numDays} days)
- Travellers: ${travellerCount}
- Total budget: $${parseInt(budget).toLocaleString()} USD
- Trip type: ${tripType}
- Accommodation: ${accom}
- Pace: ${pace}
- Interests: ${interests.length ? interests.join(', ') : 'general sightseeing'}

Return ONLY valid JSON (no markdown, no backticks) with this exact structure:
{
  "title": "Short evocative trip title",
  "summary": "2-sentence description of the trip",
  "budgetBreakdown": {
    "flights": number,
    "hotels": number,
    "activities": number
  },
  "days": [
    {
      "dayNum": 1,
      "theme": "Short day theme",
      "activities": [
        {
          "time": "9:00 AM",
          "name": "Activity name",
          "detail": "One sentence description",
          "cost": "$XX",
          "type": "sightseeing|food|transport|accommodation|activity"
        }
      ]
    }
  ]
}

Include ${Math.min(numDays, 7)} days. Each day should have 4-6 activities. Be specific with real place names, restaurants, and attractions in ${destination}. Tailor everything to the traveller's stated interests and pace.`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 4000,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    clearInterval(msgInterval);

    if (!response.ok) throw new Error('API error ' + response.status);
    const data = await response.json();
    const raw = data.content.map(b => b.text || '').join('');
    const clean = raw.replace(/```json|```/g, '').trim();
    const itinerary = JSON.parse(clean);
    renderItinerary(itinerary, destination, formattedDep, formattedRet, travellerCount, budget);

  } catch (err) {
    clearInterval(msgInterval);
    console.error(err);
    showPanel('empty');
    showToast('Could not generate itinerary. Check your API key in the browser console.');
  }
}

// ---- Render Itinerary ----
function renderItinerary(data, dest, dep, ret, travellers, budget) {
  document.getElementById('outTitle').textContent = data.title || `Your ${dest} Trip`;
  document.getElementById('outMeta').textContent = `${dep} → ${ret} · ${travellers} traveller${travellers > 1 ? 's' : ''} · $${parseInt(budget).toLocaleString()} budget`;

  const container = document.getElementById('itineraryContent');
  container.innerHTML = '';

  // Summary
  if (data.summary) {
    const s = document.createElement('p');
    s.style.cssText = 'font-size:0.88rem;color:var(--text-muted);margin-bottom:20px;line-height:1.7;font-style:italic;';
    s.textContent = data.summary;
    container.appendChild(s);
  }

  // Days
  (data.days || []).forEach((day, i) => {
    const block = document.createElement('div');
    block.className = 'day-block';
    block.style.animationDelay = `${i * 0.08}s`;

    const header = document.createElement('button');
    header.className = 'day-header' + (i === 0 ? ' open' : '');
    header.innerHTML = `
      <span class="day-label">Day ${day.dayNum}</span>
      <span class="day-title">${day.theme}</span>
      <span class="day-chevron">${i === 0 ? '▲' : '▼'}</span>
    `;
    header.addEventListener('click', () => {
      const body = block.querySelector('.day-body');
      const isOpen = body.classList.contains('open');
      body.classList.toggle('open', !isOpen);
      header.classList.toggle('open', !isOpen);
      header.querySelector('.day-chevron').textContent = isOpen ? '▼' : '▲';
    });

    const body = document.createElement('div');
    body.className = 'day-body' + (i === 0 ? ' open' : '');

    (day.activities || []).forEach(act => {
      const a = document.createElement('div');
      a.className = 'activity';
      a.innerHTML = `
        <span class="activity-time">${act.time}</span>
        <div class="activity-content">
          <div class="activity-name">${act.name}</div>
          <div class="activity-detail">${act.detail}</div>
        </div>
        <span class="activity-badge">${act.cost}</span>
      `;
      body.appendChild(a);
    });

    block.appendChild(header);
    block.appendChild(body);
    container.appendChild(block);
  });

  // Budget summary
  if (data.budgetBreakdown) {
    const { flights, hotels, activities } = data.budgetBreakdown;
    const bs = document.createElement('div');
    bs.className = 'budget-summary';
    bs.innerHTML = `
      <div class="budget-item">
        <div class="budget-item-label">✈️ Flights</div>
        <div class="budget-item-val">$${(flights || 0).toLocaleString()}</div>
      </div>
      <div class="budget-item">
        <div class="budget-item-label">🏨 Hotels</div>
        <div class="budget-item-val">$${(hotels || 0).toLocaleString()}</div>
      </div>
      <div class="budget-item">
        <div class="budget-item-label">🎯 Activities</div>
        <div class="budget-item-val">$${(activities || 0).toLocaleString()}</div>
      </div>
    `;
    container.appendChild(bs);
  }

  showPanel('output');
}

// ---- Helpers ----
function getSelectedChip(groupId) {
  const active = document.querySelector(`#${groupId} .chip.active`);
  return active ? active.dataset.val : '';
}
function getSelectedChips(groupId) {
  return [...document.querySelectorAll(`#${groupId} .chip.active`)].map(c => c.dataset.val);
}
function formatDate(dateStr) {
  return new Date(dateStr).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function showPanel(which) {
  document.getElementById('resultEmpty').style.display = which === 'empty' ? 'block' : 'none';
  document.getElementById('resultLoading').style.display = which === 'loading' ? 'block' : 'none';
  document.getElementById('resultOutput').style.display = which === 'output' ? 'block' : 'none';

  const panel = document.getElementById('resultPanel');
  if (which === 'empty') {
    panel.style.alignItems = 'center';
    panel.style.justifyContent = 'center';
  } else {
    panel.style.alignItems = which === 'loading' ? 'center' : 'flex-start';
    panel.style.justifyContent = 'flex-start';
  }
}

function resetPlanner() {
  goStep(1);
  showPanel('empty');
  document.getElementById('origin').value = '';
  document.getElementById('destination').value = '';
  document.getElementById('depDate').value = '';
  document.getElementById('retDate').value = '';
  travellerCount = 2;
  document.getElementById('travellerCount').textContent = '2';
  document.getElementById('budgetSlider').value = 3000;
  updateBudget(3000);
  document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
  document.querySelector('#tripType [data-val="leisure"]').classList.add('active');
  document.querySelector('#accomPref [data-val="hotel"]').classList.add('active');
  document.querySelector('#pace [data-val="relaxed"]').classList.add('active');
}

// Smooth nav scroll
document.querySelectorAll('a[href^="#"]').forEach(a => {
  a.addEventListener('click', e => {
    const target = document.querySelector(a.getAttribute('href'));
    if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth' }); }
  });
});
